package Sortieren;

import java.util.Scanner;

public class QuicksortZeit {

    static int[] a;

    public static void erzeugeFeld(int anzElemente) {
        a = new int[anzElemente];
        for (int i = 0; i < anzElemente; i++) {
            a[i] = (int) (Math.random() * 10 * anzElemente);
        }
    }

    public static void gibFeldAus() {
        int n = a.length;
        for (int i = 0; i < n; i++) {
            System.out.printf("%5d",a[i]);
            if (i % 25 == 24) {
                System.out.println();
            }
        }
        System.out.println();
    }

    public static void qsort(int lo, int hi, int[] a) {
        int merke;
        int i = lo;
        int j = hi;

        // Vergleichselement x (Median)
        int x = a[(lo + hi) / 2];

        //  Aufteilung
        while (i <= j) {
            while (a[i] < x) {
                i++;
            }

            while (a[j] > x) {
                j--;
            }

            if (i <= j) {
                merke = a[i];
                a[i] = a[j];
                a[j] = merke;
                i++;
                j--;
            }
        }

        // Rekursion
        if (lo < j) {
            qsort(lo, j, a);
        }

        if (i < hi) {
            qsort(i, hi, a);
        }
    }

    public static void main(String[] args) {
        int anzElemente;
        long time;
        Scanner sc = new Scanner(System.in);

        System.out.print("Wie viele Elemente im Feld: ");
        anzElemente = sc.nextInt();

        erzeugeFeld(anzElemente);
        // gibFeldAus();

        time = System.currentTimeMillis();
        qsort(0, a.length - 1, a);
        time = System.currentTimeMillis() - time;

        System.out.println("Sortiert mit Quicksort: " + time + "ms");
        // gibFeldAus();
    }
}
