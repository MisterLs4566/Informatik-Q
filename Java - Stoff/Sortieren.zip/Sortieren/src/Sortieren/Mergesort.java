package Sortieren;

import java.util.Scanner;

public class Mergesort {

    static int[] a, acopy;

    public static void erzeugeFeld(int anzElemente) {
        a = new int[anzElemente];
        acopy = new int[a.length];
        for (int i = 0; i < anzElemente; i++) {
            a[i] = (int) (Math.random() * 10 * anzElemente);
        }
    }

    public static void gibFeldAus() {
        int n = a.length;
        for (int i = 0; i < n; i++) {
            System.out.printf("%5d",a[i]);
            if (i % 25 == 24) {
                System.out.println();
            }
        }
        System.out.println();
    }

    // rekursive Variante
    public static void sort() {
        sort(a,a.length);
    }

    public static void sort(int[] a, int n) {
        if (n < 2) {
            return;
        }
        int mid = n/2;
        int[]l = new int[mid];
        int[]r = new int[n - mid];

        for (int i = 0; i < mid; i++) {
            l[i]= a[i];
        }
        for (int i = mid; i < n; i++) {
            r[i - mid]= a[i];
        }
        sort(l, mid);
        sort(r, n - mid);

        merge(a, l, r, mid, n - mid);
    }

    public static void merge(int[] a, int[] l, int[] r, int left, int right) {

        int i = 0, j = 0, k = 0;
        while (i < left && j < right) {
            if (l[i]<= r[j]) {
                a[k++]= l[i++];
            }
            else {
                a[k++]= r[j++];
            }
        }
        while (i < left) {
            a[k++]= l[i++];
        }
        while (j < right) {
            a[k++]= r[j++];
        }
    }

    // ===========================================================================================
    // iterative Variante
    public static void sortIterativ() {
        for (int s = 1; s < a.length; s += s)
            for (int m = a.length - 1 - s; m >= 0; m -= (s + s))
                mergeIterativ(Math.max(m - s + 1, 0), m, m + s, a, acopy);
    }

    public static void mergeIterativ(int lo, int m, int hi, int[] a, int[] b) {
        int i = 0, j = lo, k;

        // vordere Hälfte von a in Hilfsarray b kopieren
        while (j <= m) {
            b[i++] = a[j++];
        }

        i = 0;
        k = lo;

        // jeweils das nächstgrößte Element zurückkopieren
        while ((k < j) && (j <= hi)) {

            if (b[i] <= a[j]) {
                a[k++] = b[i++];
            } else {
                a[k++] = a[j++];
            }
        }

        // Rest von b falls vorhanden zurückkopieren
        while (k < j) {
            a[k++] = b[i++];
        }
    }

    public static void main(String[] args) {
        int anzElemente;
        Scanner sc = new Scanner(System.in);

        System.out.print("Wie viele Elemente im Feld: ");
        anzElemente = sc.nextInt();

        erzeugeFeld(anzElemente);
        gibFeldAus();

        //sort(a,a.length);
        sortIterativ();

        System.out.println("Sortiert mit Quicksort");
        gibFeldAus();
    }

}