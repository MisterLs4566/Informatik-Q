package Sortieren;

import SortierenOOM.Bubblesort;
import SortierenOOM.Input;
import SortierenOOM.Insertionsort;
import SortierenOOM.Selectionsort;

import java.util.Scanner;

public class Sortiere {

    public static int[] erzeugeFeld(int anzElemente) {
        int[] a = new int[anzElemente];
        for (int i = 0; i < anzElemente; i++) {
            a[i] = (int) (Math.random() * 10 * anzElemente);
        }
        return a;
    }

    public static void gibFeldAus(int[] a) {
        int n = a.length;
        for (int i = 0; i < n; i++) {
            System.out.printf("%5d",a[i]);
            if (i % 25 == 24) {
                System.out.println();
            }
        }
        System.out.println();
    }

    // Bubblesort
    public static int[] bubblesort(int[] a) {
        int n = a.length;
        for (int i = 0; i < n-1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (a[j] > a[j + 1]) {          // Tausch der Werte
                    int temp = a[j + 1];
                    a[j + 1] = a[j];
                    a[j] = temp;
                }
            }
        }
        return a;
    }

    // Insertionsort
    public static int[] insertionsort(int[] a) {
        int n = a.length;
        for (int i = 1; i < n; i++) {
            int key = a[i];
            int j = i - 1;
            while (j >= 0 && a[j] > key) {      // Verschiebe, solange a[j]<key
                a[j+1] = a[j];
                j--;
            }
            a[j+1] = key;                       // Füge Element ein
        }
        return a;
    }

    // Selectionsort
    public static int[] selectionsort(int[] a) {
        int n = a.length;
        for (int i = 0; i < n-1; i++) {
            int minID = i;                      // Minimum suchen
            for (int j = i+1; j < n; j++)
                if (a[j] < a[minID])
                    minID = j;
            int temp = a[minID];                // Tausche 1. Element mit kleinstem Element
            a[minID] = a[i];
            a[i] = temp;
        }
        return a;
    }

    public static void main(String[] args) {
        int[] feld, feldcopy;
        int anzElemente;
        Scanner sc = new Scanner(System.in);

        System.out.print("Wie viele Elemente im Feld: ");
        anzElemente = sc.nextInt();

        feld = erzeugeFeld(anzElemente);
        gibFeldAus(feld);
        feldcopy = new int[anzElemente];

        // Bubblesort
        System.arraycopy(feld,0,feldcopy,0,feld.length);
        feldcopy = bubblesort(feldcopy);
        System.out.println("Sortiert mit Bubblesort");
        gibFeldAus(feldcopy);
        // Insertionsort
        System.arraycopy(feld,0,feldcopy,0,feld.length);
        feldcopy = insertionsort(feldcopy);
        System.out.println("Sortiert mit Insertionsort");
        gibFeldAus(feldcopy);
        // Selectionsort
        System.arraycopy(feld,0,feldcopy,0,feld.length);
        feldcopy = selectionsort(feldcopy);
        System.out.println("Sortiert mit Selectionsort");
        gibFeldAus(feldcopy);
    }
}
